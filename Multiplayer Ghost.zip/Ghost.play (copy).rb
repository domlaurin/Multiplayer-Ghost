require_relative "Game (copy).rb"

puts "Enter any number names separated by a comma ^^"
names = gets.chomp.downcase

new_ghost_game = Game.new(names.split(", "))

new_ghost_game.play_round


# qqqqqqqppppppp: or you can make a loop where you will gets input and break from this loop if input is empty