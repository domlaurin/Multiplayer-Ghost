require_relative "Dictionary (copy).rb"
require_relative "Player (copy).rb"
require 'byebug'

class Game
    attr_accessor :fragment
    def initialize(players)
      @players_array = players.map {|name| Player.new(name)}
      @fragment = ""
      @dictionary_array = DictionaryParser.new.array
      @dictionary_hash = DictionaryParser.new.hash
      @losses = Hash.new {|losses, player| losses[player] = 0}
    end

    def play_round
      self.display_standings
      until @players_array.length == 1
          self.take_turn(current_player)
          if @losses[current_player] == 5
            puts "\n\n#{current_player.name.capitalize} - sorry, you lost and were eliminated from the game... :(\n\n"
            @players_array.shift
          end
          next_player!
      end
      puts "\n\n#{current_player.name.capitalize} - CONGRATULATIONS, YOU WON, WHOOO!!!!1! ^^\n\n"
    end

    def current_player
      @players_array[0]
    end

    def previous_player
      @players_array[-1]
    end
    
    def next_player!
      @players_array.rotate!
    end

    def take_turn(player)
      puts "Current word fragment: #{@fragment}"
      letter = player.guess
      if valid_play?(letter) == "letter not in the alphabet" 
        @losses[player] += 1
        puts "\nYou (#{player.name.capitalize}) chose the letter that's not in the alphabet, \nso YOU LOSE THE ROUND MUAHAHAHAHAHAHAHA"
        self.display_standings
        @fragment = ""
      elsif valid_play?(letter) == "(fragment + letter) is not the beginning of any word"
        @losses[player] += 1
        puts "\nYou (#{player.name.capitalize}) spelled #{@fragment.upcase}#{letter.upcase}, which is not a beginning of any word, \nso YOU LOSE THE ROUND MUAHAHAHAHAHAHAHA"
        self.display_standings
        @fragment = ""
      elsif @dictionary_hash.include?(@fragment + letter) 
        @losses[player] += 1
        puts "\nYou (#{player.name.capitalize}) spelled #{@fragment.upcase}#{letter.upcase}, which is a WORD, \nso YOU LOSE THE ROUND MUAHAHAHAHAHAHAHA"
        self.display_standings
        @fragment = ""
      else
        @fragment += letter
      end
    end

    def valid_play?(letter)
      alphabet = ("a".."z").to_a
      if !alphabet.include?(letter.downcase)
        return "letter not in the alphabet"        
      elsif @dictionary_array.none? {|word| word.start_with?(@fragment + letter)}
        return "(fragment + letter) is not the beginning of any word"
      end
    end

    def record(player)
      num_losses = @losses[player]
      ghost = "GHOST"
      return ghost[0...num_losses]
    end

    def display_standings
      @players_array.each do |player|
        puts "#{player.name.capitalize}'s losses': #{record(player)}"
      end
    end

end





# Ghost logic steps:
# 1. create Game class
# 2. create Player class
# 3. create Dictionary file

# Player class:
# 1. create initialize method
# 2. create guess method
# 3. create alert_invalid_guess method
# 4. make the player have a name

# Dictionary file:
# 1. create a dictionary_array
# 2. create a dictionary_hash

# Game class:
# 1. create initialize method
#       a. create instance variable @names
#       b. create instance variable @fragment
#       c. create instance variable @dictionary_array
#       d. create instance variable @dictionary_hash
# 2. create play_round method
#       a. run take_turn on current player until the game is lost.
#       b. in Phase 2 - when player loses - @losses[player] += 1
#       c. reset fragment to empty string ""
# 3. create current_player method
# 4. create previous_player method
# 5. create next_player! method
#       a. updates the current_player and previous_player
# 6. create take_turn(player) method
#       a. gets a string from the player until a valid play is made.
#       b. updates the fragment and checks against the @dictionary_hash.
#       c. if fragment is included in the @dictionary_hash - the player loses.
# 7. create valid_play?(string) method
#       a. checks if string is a letter in alphabet
#       b. checks if the are words we can spell after adding it to the fragment in @dictionary_array

# Phase 2 
# Game class:
# 1. create @losses hash.
#       a. the keys names
#       b. the values are number of games that the player has lost.
# 2. create record(player) method
#       a. translates number of losses into substring of "GHOST", so 4 => "GHOS"
# 3. create display_standings
#       a. display the scoreboard at the beginning of each play_round
#       b. add display_stdandings to the play_round
# 4. we will prob need to use attr_reader for @losses and some other variables.
# 5. create run method.
#       a. should call play_round until one of the names reaches 5 losses.


# qqqqqqqppppppp: do you really need fast access to the player instance using name? where this name will come from? looks like you only need access to the current player, and may be next player. and yeah, your screen is till black.

    #let's say @players_array is ["dom", "ivan", "anthony"]
    #create an empty hash using {|h,k| h[k] = Player.new}
    #iterate through @players_array and set eles to hash keys and leave it at that.
    #now our hash has players_array tied to player.new's
#set current_player to be hash[@players_array[0]]
#call a hash[current_player] to get the player instance



# check that the players_array[1] and players_array[-1] are switched correctly
# gotta change display_standings - it only shows 2 players_array now
# any instance of @players_array[1] should be changed to wok with an array of players_array
# delete #run because we're not using it