# qqqqqqqppppppp: 
# try to refactor your dictionary. global variables are evil. You can parse file right in dictionary initialize and assign this hash to the instance variable. so when you will call Dictionary.new you will get the object with hash inside
# qqqqqqqppppppp: 
# and yeah, for example you can pass path for the dictionary file as optianal argument for initializer
# qqqqqqqppppppp: 
# and you can delegate some hash methods like [] right to the instance varibale. after that you can do something like dict = Dictionary.new; dict["word"]
# qqqqqqqppppppp: 
# or make a separate parser for dictionary which retrun hash and just call this parser in game initializer
# class Dictionary

#     def initialize


class DictionaryParser
    def hash(file = "dictionary (copy).txt")
        words_array = File.open(file).read.split("\n")
        words_array.each_with_object({}) { |word, hash| hash[word] = true }
    end

    def array(file = "dictionary (copy).txt")
        words_array = File.open(file).read.split("\n")
    end
end
  
#   puts DictionaryParser.new.array[4]

# $dictionary_array = $dictionary.split("\n")
# $dictionary_hash = {}
# $dictionary_array.each {|word| $dictionary_hash[word] = true}

# qqqqqqqppppppp: this is expample of simple parser which takes txt file and returns hash
# qqqqqqqppppppp: you can call this in Game initializer
# qqqqqqqppppppp: and get rid of your global var
# qqqqqqqppppppp: this is just the name of the method